Vacation Planner Android App

This project gave me the opportunity to gain hands-on experience with Android app development using
a Software Development Kit (SDK). Throughout the course, I learned how to install and use an SDK,
build a basic Android mobile app with a graphical user interface (GUI), adapt applications for
different devices, save data, run and debug apps using emulators, and deploy an Android
 application.

What I accomplished:

Built a vacation planner app that allows users to schedule custom vacations with related excursions,
including data validation and full CRUD functionality.
Enhanced the user experience by adding features like date scheduling, alerts, and sharing options.
Created a user guide and generated a signed APK to deploy the app on the Google Play Store.

Basic Setup Instructions

Clone the project:
https://gitlab.com/wgu-gitlab-environment/student-repos/jwri817/d308-mobile-application-development-android.git

Open the project in Android Studio.
Run the app using either the Android emulator or a physical Android device connected via USB or Wi-Fi.

How to Use
From the home screen, tap "Vacation Planner" to open the Vacation List page, where all added vacations will appear.
To add sample data without entering information manually:
Tap the three dots in the top-right corner.
Select "Add Sample Data."
Go back to the Home Page, then tap "Vacation Planner" again to view the sample vacations.

To add a new vacation:
Tap the plus (+) button on the Vacation List page.
Enter the vacation title, hotel name, start date, and end date.
Open the menu (three dots) and select "Save Vacation."

To set alerts, use the same menu and choose "Alert on vacation Start," "Alert on vacation End,"
to receive notifications for those dates.

To share vacation details, select "Share" from the menu and choose your preferred sharing method.

To update an existing vacation:
From the Vacation List, select the vacation you want to edit, make changes, and then select
 "Save Vacation."

To delete a vacation:
From the Vacation List, select the vacation and choose "Delete Vacation" from the menu.

Note: A vacation's end date must be after its start date.

Adding Excursions
From the Vacation Details page, tap the plus (+) button to add an excursion.
Enter the excursion title and date.
Open the menu and select "Save Excursion" to save it to the database.

To set a reminder, open the menu and select "Notify Excursion" to receive a notification on the
 excursion date.

Note: The excursion date must be within the vacation's start and end dates.