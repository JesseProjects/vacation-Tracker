package com.jessewright.vacationapp.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.jessewright.vacationapp.dao.ExcursionDAO;
import com.jessewright.vacationapp.dao.VacationDAO;
import com.jessewright.vacationapp.entities.Excursion;
import com.jessewright.vacationapp.entities.Vacation;

@Database(entities = {Vacation.class, Excursion.class}, version=1, exportSchema = false)
public abstract class VacationDatabaseBuilder extends RoomDatabase {
    public abstract VacationDAO vacationDAO();
    public abstract ExcursionDAO excursionDAO();
    private static volatile VacationDatabaseBuilder INSTANCE;

    static VacationDatabaseBuilder getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (VacationDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            VacationDatabaseBuilder.class, "vacation_database.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}