package com.jessewright.vacationapp.UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.net.ParseException;

import com.jessewright.vacationapp.R;
import com.jessewright.vacationapp.database.Repository;
import com.jessewright.vacationapp.entities.Excursion;
import com.jessewright.vacationapp.entities.Vacation;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ExcursionDetails extends AppCompatActivity {

    String excTitle, excDate, excDetails;
    int excID, vacID;
    EditText editExcTitle, editExcDetails;
    TextView editExcDate;
    Spinner spinner;
    Repository repository;
    DatePickerDialog.OnDateSetListener startDate;
    final Calendar myCalendarStart = Calendar.getInstance();
    ArrayList<Vacation> vacationArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_excursion_details);

        repository = new Repository(getApplication());

        // Get values from intent
        excTitle = getIntent().getStringExtra("excTitle");
        excDetails = getIntent().getStringExtra("excDetails");
        excID = getIntent().getIntExtra("excID", -1);
        vacID = getIntent().getIntExtra("vacID", -1);

        // Setup UI references
        editExcTitle = findViewById(R.id.excursionTitle);
        editExcDetails = findViewById(R.id.excursionDetails);
        editExcDate = findViewById(R.id.excursionDate);
        spinner = findViewById(R.id.spinner);

        editExcTitle.setText(excTitle);
        editExcDetails.setText(excDetails);

        // --- Date Picker ---
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editExcDate.setOnClickListener(v -> {
            String info = editExcDate.getText().toString();
            if (info.equals("")) info = "07/01/25";
            try {
                myCalendarStart.setTime(sdf.parse(info));
            } catch (Exception e) {
                e.printStackTrace();
            }

            new DatePickerDialog(
                    ExcursionDetails.this,
                    startDate,
                    myCalendarStart.get(Calendar.YEAR),
                    myCalendarStart.get(Calendar.MONTH),
                    myCalendarStart.get(Calendar.DAY_OF_MONTH)
            ).show();
        });

        startDate = (view, year, month, dayOfMonth) -> {
            myCalendarStart.set(Calendar.YEAR, year);
            myCalendarStart.set(Calendar.MONTH, month);
            myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabelStart();
        };

        // --- Spinner setup ---
        vacationArrayList = new ArrayList<>(repository.getAllVacations());
        ArrayAdapter<Vacation> vacationAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, vacationArrayList
        );
        vacationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(vacationAdapter);

        // Preselect correct vacation for this excursion (if editing)
        for (int i = 0; i < vacationArrayList.size(); i++) {
            if (vacationArrayList.get(i).getVacationID() == vacID) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editExcDate.setText(sdf.format(myCalendarStart.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_excursiondetails, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }

        // --- SAVE Excursion ---
        if (item.getItemId() == R.id.excursionsave) {
            Vacation selectedVacation = (Vacation) spinner.getSelectedItem();
            int selectedVacID = selectedVacation.getVacationID();

            //validates the excursion date.
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
                Date excursionDate = sdf.parse(editExcDate.getText().toString());
                Date vacationStart = new SimpleDateFormat("MM/dd/yyyy", Locale.US)
                        .parse(selectedVacation.getVacationStartDate());
                Date vacationEnd = new SimpleDateFormat("MM/dd/yyyy", Locale.US)
                        .parse(selectedVacation.getVacationEndDate());

                if (excursionDate.before(vacationStart) || excursionDate.after(vacationEnd)) {
                    Toast.makeText(this,
                            "Excursion date must be within the vacation period (" +
                                    selectedVacation.getVacationStartDate() + " - " +
                                    selectedVacation.getVacationEndDate() + ")", Toast.LENGTH_LONG).show();
                    return true;
                }
            } catch (Exception e) {
                Toast.makeText(this, "Invalid excursion or vacation date format", Toast.LENGTH_SHORT).show();
                return true;
            }


            Excursion excursion;
            //adding the excursion
            if (excID == -1) {
                if (repository.getAllExcursions().isEmpty()) {
                    excID = 1;
                } else {
                    excID = repository.getAllExcursions()
                            .get(repository.getAllExcursions().size() - 1)
                            .getExcursionID() + 1;
                }

                excursion = new Excursion(
                        excID,
                        editExcTitle.getText().toString(),
                        editExcDetails.getText().toString(),
                        editExcDate.getText().toString(),
                        selectedVacID
                );
                repository.insert(excursion);
            } else { // Update existing
                excursion = new Excursion(
                        excID,
                        editExcTitle.getText().toString(),
                        editExcDetails.getText().toString(),
                        editExcDate.getText().toString(),
                        selectedVacID
                );
                repository.update(excursion);
            }

            Toast.makeText(this, "Excursion saved", Toast.LENGTH_SHORT).show();
            this.finish();
            return true;
        }

        // --- DELETE Excursion ---
        if (item.getItemId() == R.id.excursiondelete) {
            Excursion excursion = new Excursion(
                    excID,
                    editExcTitle.getText().toString(),
                    editExcDetails.getText().toString(),
                    editExcDate.getText().toString(),
                    vacID
            );
            repository.delete(excursion);
            Toast.makeText(this, "Excursion deleted", Toast.LENGTH_SHORT).show();
            this.finish();
            return true;
        }

        // --- Notification ---
        if (item.getItemId() == R.id.excursionnotify) {
            String dateFromScreen = editExcDate.getText().toString();
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(dateFromScreen);
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (java.text.ParseException e) {
                throw new RuntimeException(e);
            }
            Long trigger = myDate.getTime();
            Intent intent = new Intent(ExcursionDetails.this, MyReceiver.class);
            intent.putExtra("excursionTitle", editExcTitle.getText().toString());
            intent.putExtra("excursionDetails", editExcDetails.getText().toString());
            intent.putExtra("excursionDate", editExcDate.getText().toString());

            PendingIntent sender = PendingIntent.getBroadcast(ExcursionDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
