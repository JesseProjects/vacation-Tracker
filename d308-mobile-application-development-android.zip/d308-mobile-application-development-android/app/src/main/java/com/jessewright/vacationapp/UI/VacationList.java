package com.jessewright.vacationapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;



import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jessewright.vacationapp.R;
import com.jessewright.vacationapp.database.Repository;
import com.jessewright.vacationapp.entities.Excursion;
import com.jessewright.vacationapp.entities.Vacation;

import java.util.List;

public class VacationList extends AppCompatActivity {
    private Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vacation_list);
        //floating action button that take to the Vacation Details.
        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VacationList.this, VacationDetails.class);
                startActivity(intent);
            }
        });

        //wiring the adaptor up to the recycler view
        RecyclerView recyclerView = findViewById(R.id.recyclerview);  //Start the recycler view
        repository = new Repository(getApplication());                //get repository
        List<Vacation> allVacations = repository.getAllVacations();   //get list from it
        final VacationAdapter vacationAdapter = new VacationAdapter(this);//making adapter
        recyclerView.setAdapter(vacationAdapter);                   //associated adapter to view
        recyclerView.setLayoutManager(new LinearLayoutManager(this));//link layout
        vacationAdapter.setVacations(allVacations);                 //method from adaptor


        //System.out.println(getIntent().getStringExtra("Test"));// grabs the data from the intent


        //view
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    //Create the menu from the menu.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacation_list, menu);
        return true;
    }
    //resume method to update the recycler view.
    protected void onResume() {
        super.onResume();
        List<Vacation> allVacations=repository.getAllVacations();
        RecyclerView recyclerView=findViewById(R.id.recyclerview);
        final VacationAdapter vacationAdapter=new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        vacationAdapter.setVacations(allVacations);
    }
    //Create the menu items based on the menu.xml
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.sample) {
            repository = new Repository(getApplication());

            //Toast.makeText(VacationList.this, "Put in sample data", Toast.LENGTH_SHORT).show();
            Vacation vacation1 = new Vacation(1, "Cancun", "Hilton", "01/01/25",
                    "01/05/25", "A mexican get away", false, false);
            repository.insert(vacation1);
            Vacation vacation2 = new Vacation(2, "Hawaii", "Marriott", "01/08/25",
                    "01/15/25", "A tropical get away", false, false);
            repository.insert(vacation2);

            //i enter 0 for vacation id , probably need to create a const without and without it.
            Excursion excursion1 = new Excursion(0, "Jet Ski",
                    "Blast across the ocean, lots of other interesting details of sample data," +
                            "lots of other interesting details of sample data", "01/01/25", 1);
            repository.insert(excursion1);
            Excursion excursion2 = new Excursion(0, "Sky Diving",
                    "Fall out of the sky, lots of other interesting details of sample data," +
                            "lots of other interesting details of sample data", "01/07/25", 2);
            repository.insert(excursion2);


            return true;
        }
        //that you back to the Main Activity page when Home button is pressed on phone.
        if (item.getItemId() == android.R.id.home) {
            this.finish();

            return true;
        }
        return true;
    }


}