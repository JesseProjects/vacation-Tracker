package com.jessewright.vacationapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "excursions")
public class Excursion {
    @PrimaryKey(autoGenerate = true)
    private int excursionID;
    private String excursionTitle;
    private String excursionDetails;
    private String excursionDate;
    private int vacationID;


    //constructor
    public Excursion(int excursionID, String excursionTitle, String excursionDetails, String excursionDate, int vacationID) {
        this.excursionID = excursionID;
        this.excursionTitle = excursionTitle;
        this.excursionDetails = excursionDetails;
        this.excursionDate = excursionDate;
        this.vacationID = vacationID;
    }
    // Getters and setters

    public int getExcursionID() {
        return excursionID;
    }

    public void setExcursionID(int excursionID) {
        this.excursionID = excursionID;
    }

    public String getExcursionTitle() {
        return excursionTitle;
    }

    public void setExcursionTitle(String excursionTitle) {
        this.excursionTitle = excursionTitle;
    }

    public String getExcursionDetails() {
        return excursionDetails;
    }

    public void setExcursionDetails(String excursionDetails) {
        this.excursionDetails = excursionDetails;
    }

    public String getExcursionDate() {
        return excursionDate;
    }

    public void setExcursionDate(String excursionDate) {
        this.excursionDate = excursionDate;
    }

    public int getVacationID() {
        return vacationID;
    }

    public void setVacationID(int vacationID) {
        this.vacationID = vacationID;
    }
}
