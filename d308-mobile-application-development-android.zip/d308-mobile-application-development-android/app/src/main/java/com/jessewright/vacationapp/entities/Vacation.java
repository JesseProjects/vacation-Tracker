
package com.jessewright.vacationapp.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "vacations")
public class Vacation {

    //fields of the table
    @PrimaryKey(autoGenerate = true)
    private int vacationID;
    private String vacationTitle;
    private String vacationStartDate;
    private String vacationEndDate;
    private String vacationDetails;
    private String vacationHotel;
    private boolean switchStartAlert;
    private boolean switchEndAlert;




    //constructor
    public Vacation(int vacationID, String vacationTitle, String vacationHotel, String vacationStartDate, String vacationEndDate, String vacationDetails, boolean switchStartAlert, boolean switchEndAlert) {
        this.vacationID = vacationID;
        this.vacationTitle = vacationTitle;
        this.vacationStartDate = vacationStartDate;
        this.vacationEndDate = vacationEndDate;
        this.vacationDetails = vacationDetails;
        this.vacationHotel = vacationHotel;
        this.switchStartAlert = switchStartAlert;
        this.switchEndAlert = switchEndAlert;


    }

    //Getters and Setters
    public int getVacationID() {
        return vacationID;
    }

    public void setVacationID(int vacationID) {
        this.vacationID = vacationID;
    }

    public String getVacationTitle() {
        return vacationTitle;
    }

    public void setVacationTitle(String vacationTitle) {
        this.vacationTitle = vacationTitle;
    }

    public String getVacationHotel() {
        return vacationHotel;
    }

    public void setVacationHotel(String vacationHotel) {
        this.vacationHotel = vacationHotel;
    }
    public String getVacationStartDate() {
        return vacationStartDate;
    }

    public void setVacationStartDate(String vacationStartDate) {
        this.vacationStartDate = vacationStartDate;
    }

    public String getVacationEndDate() {
        return vacationEndDate;
    }

    public void setVacationEndDate(String vacationEndDate) {
        this.vacationEndDate = vacationEndDate;
    }

    public String getVacationDetails() {
        return vacationDetails;
    }

    public void setVacationDetails(String vacationDetails) {
        this.vacationDetails = vacationDetails;
    }

    public boolean isSwitchStartAlert() {
        return switchStartAlert;
    }

    public void setSwitchStartAlert(boolean switchStartAlert) {
        this.switchStartAlert = switchStartAlert;
    }

    public boolean isSwitchEndAlert() {
        return switchEndAlert;
    }

    public void setSwitchEndAlert(boolean switchEndAlert) {
        this.switchEndAlert = switchEndAlert;
    }

    @Override
    public String toString() {
        return vacationTitle + " " + vacationStartDate + " " + vacationEndDate;
    }

}
