package com.jessewright.vacationapp.UI;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;

import com.jessewright.vacationapp.R;

public class MyReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "vacation_alerts";
    private static int notificationID = 0;

    @Override
    public void onReceive(Context context, Intent intent) {

        Toast.makeText(context, "Notification received", Toast.LENGTH_LONG).show();

        String vacationTitle = intent.getStringExtra("vacationTitle");
        String alertType = intent.getStringExtra("alertType");

        String excursionTitle = intent.getStringExtra("excursionTitle");
        String excursionDate = intent.getStringExtra("excursionDate");
        String excursionDetails = intent.getStringExtra("excursionDetails");

        createNotificationChannel(context);

        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Notification notification;

        // --- Handle excursion alerts ---
        if (excursionTitle != null && excursionDate != null) {
            String excursionMessage = "Excursion \"" + excursionTitle + "\" on " + excursionDate + "!";
            Log.d("VacationAlert", excursionMessage);

            // ✅ Added toast for excursion alerts
            Toast.makeText(context, excursionMessage, Toast.LENGTH_LONG).show();

            notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Excursion Alert")
                    .setContentText(excursionMessage)
                    .setStyle(new NotificationCompat.BigTextStyle()
                            .bigText("Excursion: " + excursionTitle +
                                    "\nDate: " + excursionDate +
                                    "\nDetails: " + excursionDetails))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build();

        } else {
            // --- Handle vacation alerts ---
            if (vacationTitle == null) vacationTitle = "Vacation";
            if (alertType == null) alertType = "starting/ending";

            String vacationMessage = vacationTitle + " is approaching " + alertType;
            Log.d("VacationAlert", vacationMessage);

            // ✅ Added toast for vacation alerts
            Toast.makeText(context, vacationMessage, Toast.LENGTH_LONG).show();

            notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Vacation Alert")
                    .setContentText(vacationMessage)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build();
        }

        notificationManager.notify(notificationID++, notification);
    }

    private void createNotificationChannel(Context context) {
        CharSequence name = "Vacation Alerts";
        String description = "Notifications for vacation start and end dates";
        int importance = NotificationManager.IMPORTANCE_DEFAULT;

        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager notificationManager =
                context.getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);
    }
}
