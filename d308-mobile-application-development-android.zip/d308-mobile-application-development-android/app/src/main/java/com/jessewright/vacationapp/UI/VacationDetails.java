package com.jessewright.vacationapp.UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jessewright.vacationapp.R;
import com.jessewright.vacationapp.database.Repository;
import com.jessewright.vacationapp.entities.Excursion;
import com.jessewright.vacationapp.entities.Vacation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VacationDetails extends AppCompatActivity {
    int vacationID;
    String title;
    String hotel;
    String startDate;
    String endDate;
    String vacationDetails;
    EditText editTitle;
    EditText editHotel;
    EditText editStartDate;
    EditText editEndDate;
    EditText editVacationDetails;
    int numExcursions;
    Vacation currentVacation;
    Repository repository;
    Switch switchStartAlert;
    Switch switchEndAlert;

    final Calendar calendar = Calendar.getInstance(); // used for date pickers

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vacation_details);

        // Wiring up alarm switches
        switchStartAlert = findViewById(R.id.switchStartAlert);
        switchEndAlert = findViewById(R.id.switchEndAlert);

        // Wiring up text fields
        editTitle = findViewById(R.id.titleText);
        editHotel = findViewById(R.id.hotelText);
        editStartDate = findViewById(R.id.startDateText);
        editEndDate = findViewById(R.id.endDateText);
        editVacationDetails = findViewById(R.id.vacationDetailsText);

        // Get data from intent
        title = getIntent().getStringExtra("title");
        hotel = getIntent().getStringExtra("hotel");
        startDate = getIntent().getStringExtra("startDate");
        endDate = getIntent().getStringExtra("endDate");
        vacationDetails = getIntent().getStringExtra("details");

        vacationID = getIntent().getIntExtra("id", -1);

        // Populate data
        editTitle.setText(title);
        editHotel.setText(hotel);
        editStartDate.setText(startDate);
        editEndDate.setText(endDate);
        editVacationDetails.setText(vacationDetails);

        // DatePicker setup for Start Date
        editStartDate.setOnClickListener(v -> showDatePickerDialog(editStartDate));

        // DatePicker setup for End Date
        editEndDate.setOnClickListener(v -> showDatePickerDialog(editEndDate));

        // Floating Action Button to go to ExcursionDetails
        FloatingActionButton fab = findViewById(R.id.floatingActionButton2);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(VacationDetails.this, ExcursionDetails.class);
            startActivity(intent);
        });

        // RecyclerView setup
        RecyclerView recyclerView = findViewById(R.id.excursionRecyclerView);
        repository = new Repository(getApplication());
        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion p : repository.getAllExcursions()) {
            if (p.getVacationID() == vacationID) filteredExcursions.add(p);
        }
        excursionAdapter.setExcursions(filteredExcursions);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // DatePickerDialog helper function
    private void showDatePickerDialog(EditText targetField) {
        final Calendar currentDate = Calendar.getInstance();
        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                VacationDetails.this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                    targetField.setText(sdf.format(selectedDate.getTime()));
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacationdetails, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Allow back arrow to work
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }

        // Allows to save
        if (item.getItemId() == R.id.vacationsave) {

            String start = editStartDate.getText().toString();
            String end = editEndDate.getText().toString();

            //verify there is a date.
            if (start.isEmpty() || end.isEmpty()) {
                Toast.makeText(VacationDetails.this, "Please enter a start and end date", Toast.LENGTH_SHORT).show();
                return true;
            }

            //convert the date for the vacation in to a alert time.
            String myFormat = "MM/dd/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myStartDate = null;
            Date myEndDate = null;
            try {
                myStartDate  = sdf.parse(start);
               // Toast.makeText(this, "Start date: " + sdf.format(myStartDate), Toast.LENGTH_SHORT).show();
                myEndDate  = sdf.parse(end);
              //  Toast.makeText(this, "End date: " + sdf.format(myEndDate), Toast.LENGTH_SHORT).show();


                // Schedule alerts if switches are checked
                if (switchStartAlert.isChecked()) {
                    scheduleVacationAlert(editTitle.getText().toString(), "Start Date." , myStartDate.getTime());
                }
                if (switchEndAlert.isChecked()) {
                    scheduleVacationAlert(editTitle.getText().toString(), "End Date.", myEndDate.getTime());
                }

                //validate period of dates

                if (myEndDate.before(myStartDate)) {
                    Toast.makeText(this, "End date must be after start date", Toast.LENGTH_LONG).show();
                    return true;
                }

            } catch (Exception e) {
                Toast.makeText(this, "Invalid date format", Toast.LENGTH_SHORT).show();
                return true;
            }

            // Save vacation
            Vacation vacation;
            if (vacationID == -1) {
                if (repository.getAllVacations().size() == 0)
                    vacationID = 1;
                else
                    vacationID = repository.getAllVacations().get(repository.getAllVacations().size() - 1).getVacationID() + 1;

                vacation = new Vacation(vacationID,
                        editTitle.getText().toString(),
                        editHotel.getText().toString(),
                        editStartDate.getText().toString(),
                        editEndDate.getText().toString(),
                        editVacationDetails.getText().toString(),
                        switchStartAlert.isChecked(),
                        switchEndAlert.isChecked());
                repository.insert(vacation);
                finish();
            } else {
                vacation = new Vacation(vacationID,
                        editTitle.getText().toString(),
                        editHotel.getText().toString(),
                        editStartDate.getText().toString(),
                        editEndDate.getText().toString(),
                        editVacationDetails.getText().toString(),
                        switchStartAlert.isChecked(),
                        switchEndAlert.isChecked());
                repository.update(vacation);
                finish();
            }
        }

        if (item.getItemId() == R.id.vacationdelete) {
            for (Vacation vac : repository.getAllVacations()) {
                if (vac.getVacationID() == vacationID) currentVacation = vac;
            }
            numExcursions = 0;
            for (Excursion ex : repository.getAllExcursions()) {
                if (ex.getVacationID() == vacationID) ++numExcursions;
            }
            if (numExcursions == 0) {
                repository.delete(currentVacation);
                Toast.makeText(VacationDetails.this, currentVacation.getVacationTitle() + " was deleted", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(VacationDetails.this, "Cannot delete vacation with excursions", Toast.LENGTH_SHORT).show();
            }
        }

        //Share Vacation
        if (item.getItemId() == R.id.vacationshare) {
            Intent sentIntent= new Intent();
            sentIntent.setAction(Intent.ACTION_SEND);
            sentIntent.putExtra(Intent.EXTRA_TITLE, "Vacation: " +editTitle.getText().toString());
            sentIntent.putExtra(Intent.EXTRA_TEXT, "Details: " +editVacationDetails.getText().toString() + "\n" +
                    "Hotel: " +editHotel.getText().toString() + "\n" +
                    "Start Date: " +editStartDate.getText().toString() + "\n" +
                    "End Date: " +editEndDate.getText().toString());
            sentIntent.setType("text/plain");
            Intent shareIntent=Intent.createChooser(sentIntent,null);
            startActivity(shareIntent);
            return true;
        }

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        RecyclerView recyclerView = findViewById(R.id.excursionRecyclerView);
        final ExcursionAdapter partAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(partAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion p : repository.getAllExcursions()) {
            if (p.getVacationID() == vacationID) filteredExcursions.add(p);
        }
        partAdapter.setExcursions(filteredExcursions);
    }

    // Schedule an alarm for a vacation
    private void scheduleVacationAlert(String vacationTitle, String alertType, long timeInMillis) {

        Intent intent = new Intent(VacationDetails.this, MyReceiver.class);
        intent.putExtra("vacationTitle", vacationTitle);
        intent.putExtra("alertType", alertType);
        PendingIntent sender = PendingIntent.getBroadcast(VacationDetails.this,++MainActivity.numAlert,intent,PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, timeInMillis, sender);

    }
}
