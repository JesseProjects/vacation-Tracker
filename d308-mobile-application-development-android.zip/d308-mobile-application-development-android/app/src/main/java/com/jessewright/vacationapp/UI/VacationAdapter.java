package com.jessewright.vacationapp.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.jessewright.vacationapp.R;
import com.jessewright.vacationapp.entities.Vacation;

import java.util.List;

public class VacationAdapter extends RecyclerView.Adapter<VacationAdapter.VacationViewHolder> {

    private List<Vacation> mVacations;
    private final Context context;
    private final LayoutInflater mInflater;


    public VacationAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    public class VacationViewHolder extends RecyclerView.ViewHolder {
        //item view
        private final TextView vacationItemView;
        public VacationViewHolder(@NonNull View itemView) {    //item selection
            super(itemView);
            vacationItemView = itemView.findViewById(R.id.textView3);// this links to the vacation_list_item.xml
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view){
                    int position = getAdapterPosition();
                    final Vacation current=mVacations.get(position);
                    Intent intent=new Intent(context,VacationDetails.class); //attach the information to send
                    intent.putExtra("id",current.getVacationID());       //function from entities class
                    intent.putExtra("title",current.getVacationTitle()); //data if from list.
                    intent.putExtra("hotel",current.getVacationHotel()); //data tag will be label as the text field.
                    intent.putExtra("startDate",current.getVacationStartDate());
                    intent.putExtra("endDate",current.getVacationEndDate());
                    intent.putExtra("details",current.getVacationDetails());
                    context.startActivity(intent);


                }

            });
        }
    }

    @NonNull
    @Override
    public VacationAdapter.VacationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.vacation_list_item, parent, false);
        return new VacationViewHolder(itemView); //inflation
    }

    @Override //what is display in recycling view
    public void onBindViewHolder(@NonNull VacationAdapter.VacationViewHolder holder, int position) {
        if(mVacations != null) {
            Vacation current = mVacations.get(position);
            String title = current.getVacationTitle();
            holder.vacationItemView.setText(title);
        }
        else{
            holder.vacationItemView.setText("No vacations");
        }
    }

    @Override //controls display amount of items.
    public int getItemCount() {
        if (mVacations != null) {
            return mVacations.size();
        }
        else return 0;
    }
    public void setVacations(List<Vacation> vacations){
        mVacations = vacations;
        notifyDataSetChanged();
    }


}
